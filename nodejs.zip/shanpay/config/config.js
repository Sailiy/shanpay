/**
 * Created by Administrator on 2017/8/8.
 */
const config = {

    //商户号（6位数字）
    user_seller: "385469",

    //↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
    //合作身份者PID，签约账号，由16位纯数字组成的字符串，请登录商户后台查看
    partner: "738513346376621",

    // MD5密钥，安全检验码，由数字和字母组成的32位字符串，请登录商户后台查看
    key: "JHeP76Kzd8aMQv8GZxZ3Gi8NgI2gfgAW",

    // 服务器异步通知页面路径  需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
    notify_url: "http://www.xisese.com:3000/pay/notify_url",

    // 页面跳转同步通知页面路径 需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
    return_url: "http://www.xisese.com:3000/pay/return_url",

    // 订单提交地址
    post_url:"http://pay.passpay.net/PayOrder/payorder"
}

module.exports=config